from tasks import task1,task2
def main():
    print "started"
    task1()
    print " Task 1 Finished  \n\nStarting 2\n\n"	
    task2()
   
    

main()
